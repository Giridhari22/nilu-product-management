import React from 'react'
import { Col, Button, Row, Form, Card, Container } from "react-bootstrap"
import { Link, Navigate, useNavigate } from 'react-router-dom';

function Addproduct() {
    const navigate = useNavigate();
    const backtoHome = () => {
        navigate('/home')
    }
    return (
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
            
                <h3 style={{marginLeft: "45%"}}>Add Product</h3 >
              <Button style={{marginLeft: "35%"}} onClick={backtoHome}>Back</Button>
            </nav>
            <Container>
                <Row className="vh-100 d-flex justify-content-center align-items-center">
                    <Col md={8} lg={6} xs={12}>
                        <div className="border border-3 border-primary"></div>
                        <Card className="shadow">
                            <Card.Body>
                                <div className="mb-3 mt-md-4">
                                    <h2 className="fw-bold mb-2 text-uppercase ">Add Product</h2>
                                    <div className="mb-3">
                                        <Form method='POST' >
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label className="text-center" aria-required>
                                                    Product Name
                                                </Form.Label>
                                                <Form.Control type="text" placeholder="Product" required />
                                            </Form.Group>

                                            <Form.Group
                                                className="mb-3"
                                                controlId="formBasicPassword"
                                            >
                                                <Form.Label aria-required>Product Price</Form.Label>
                                                <Form.Control type="text" placeholder="Price" required />
                                            </Form.Group>
                                            <Form.Group as={Col} controlId="formGridState">
                                                <Form.Label>Category</Form.Label>
                                                <Form.Select defaultValue="Category" placeholder="Category" required>
                                                    <option>Electronics</option>
                                                    <option>IOS</option>
                                                    <option>Android</option>
                                                    <option>Beauty</option>
                                                </Form.Select>
                                            </Form.Group>
                                            <br></br>
                                            <div className="d-grid" mb-3>
                                                <Button variant="primary" type="submit" value="addProduct" >
                                                    Add
                                                </Button>

                                            </div>
                                        </Form>
                                    </div>
                                </div>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </div >
    )
}

export default Addproduct