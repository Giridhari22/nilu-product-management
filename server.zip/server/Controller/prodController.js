const Nilproduct_obj = require('../Models/prodModel');
const { Op } = require("sequelize");

exports.addProduct = async(req, res) => {
    try {
        console.log(req.body);
    
        const prdt = {
            product1: req.body.product1,
            productPrice: req.body.productPrice,
            category: req.body.category,
            userId : req.body.userId
        };
        let created_product = await Nilproduct_obj.create(prdt);
        res.status(201).json({product : created_product});
    } catch (error) {
        console.log(error)
    }
}


exports.getProduct = async(req, res) => {
    try {
        console.log(req.body);
    
        const data  = await Nilproduct_obj.findAll({where:{userId:req.query.userId}});
        res.status(201).json({product : data});
    } catch (error) {
        console.log(error)
    }
}


exports.getSearch = async(req, res) =>{
    try {
        const {product1} = req.query;
        console.log(req.query);

        const results = await Nilproduct_obj.findAll({
            where: {
                userId:{
                    [Op.like]:`%${req.query.userId}%`
                },
                product1:{
                    [Op.like]:`%${req.query.product1}%`
                }
            }
        })
       return res.json({success: true, items: results})
    } catch (error) {
        
    }
}