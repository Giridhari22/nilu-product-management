const express = require('express');
const router = express.Router();
const { signup, signin } = require('../Controller/userController');
const { addProduct, getProduct, getSearch } = require('../Controller/prodController');
const { userValidation } = require('../Middleware/user.validate');



router.post('/sign-up', userValidation, signup);
router.post('/sign-in', signin);



router.post('/add-product', addProduct);
router.get('/get-product', getProduct);
router.get('/search-product', getSearch);


module.exports = router;